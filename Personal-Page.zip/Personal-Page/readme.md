## Personal Website Build
----
Languages Used:
- HTML
- CSS
---
For those of you looking into my work, I am learning to code on my own. I am currently devoting 3 days a week to coding and with that I am wanting to build out different projects to document the journey of the code. 

I went ahead and used the basic knowlege from teamtreehouse courses that I have been taking. This was uploaded as practice to getting familiar with github and to show proof of continued self-taught coding consistency. 

Thank you for following the journey!


